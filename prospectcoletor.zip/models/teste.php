<?php
include_once('../DAO/DAOUsuario.php');
use dao\DAOUsuario;

$daoUsuario = new DAOUsuario();

/*try{
   $daoUsuario->incluirUsuario("raul", "raul@gmail.com", "raul", "raul");
}catch(\Exception $e){
   echo $e->getMessage();
}*/
?>