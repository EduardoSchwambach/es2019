<?php
    namespace CONTROLLERS;
    require_once('../../DAO/DAOUsuario.php');
    use DAO\DAOUsuario;

    class ControllerUsuario{
       
        public function fazerLogin($login, $senha){
            $daoUsuario = new DAOUsuario();

            $usuario = $daoUsuario -> logar($login, $senha);

            unset($daoUsuario);
            return $usuario;
        }

        public function fazerLogin($login, $senha){


        public function salvarUsuario($nome, $email, $login, $senha){
            $daoUsuario = new DAOUsuario();


            try{
                $retorno = $daoUsuario->incluirUsuario($nome, $email, $login, $senha);
                unset($daoUsuario);
                return $retorno;

            }catch(\Exception $e){
                throw new \Exception($e->getMessage());
            }
        }
    }

?>